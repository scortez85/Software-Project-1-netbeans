package softwareproject1;

public class CourseException extends RuntimeException{
	public CourseException(){}
}