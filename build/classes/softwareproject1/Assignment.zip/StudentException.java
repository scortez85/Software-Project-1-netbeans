package softwareproject1;

public class StudentException extends RuntimeException{
	public StudentException(){}
}